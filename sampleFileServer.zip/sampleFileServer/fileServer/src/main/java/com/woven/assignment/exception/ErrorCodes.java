package com.woven.assignment.exception;

public class ErrorCodes {
    public static final String WOVEN_FILE_SERVICE_SIZE_EXCEEDED_CODE = "WOVEN_FILE_SERVICE_SIZE_EXCEEDED";
}
