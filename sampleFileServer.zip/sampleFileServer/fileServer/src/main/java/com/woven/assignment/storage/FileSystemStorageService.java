package com.woven.assignment.storage;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.woven.assignment.exception.ErrorResponse;
import com.woven.assignment.exception.FileNotFound;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.util.FileSystemUtils;
import org.springframework.web.multipart.MultipartFile;

@Service
public class FileSystemStorageService implements StorageService {

	private final Path rootLocation;
	private final StorageProperties storageProperties;
	public static final String SLASH = "/";

	@Autowired
	public FileSystemStorageService(StorageProperties properties) {
		this.rootLocation = Paths.get(properties.getLocation());
		this.storageProperties = properties;
	}



	@Override
	public void store(MultipartFile file) {
		try {
			if (file.isEmpty()) {
				throw new StorageException("Failed to store empty file.");
			}
			Path destinationFile = this.rootLocation.resolve(
					Paths.get(file.getOriginalFilename()))
					.normalize().toAbsolutePath();
			if (!destinationFile.getParent().equals(this.rootLocation.toAbsolutePath())) {
				// This is a security check
				throw new StorageException(
						"Cannot store file outside current directory.");
			}
      if (!destinationFile.toFile().exists()){
        FileUtils.touch(destinationFile.toFile());
      }
			try (InputStream inputStream = file.getInputStream()) {
        StandardCopyOption copyOption = StandardCopyOption.REPLACE_EXISTING;
				Files.copy(inputStream, destinationFile,copyOption);
			}
		}
		catch (IOException e) {
			throw new StorageException("Failed to store file.", e);
		}
	}

	@Override
	public List<String> listAll() {
		File file = new File(storageProperties.getLocation());
		String[] files = file.list();
		return  Arrays.asList(files);
	}

	@Override
	public void delete(String fileName) {
		String fileSeparator= FileSystems.getDefault().getSeparator();
		File file = new File(storageProperties.getLocation() + fileSeparator + fileName);
		if (!file.exists()) {
			throw new FileNotFound(new ErrorResponse("FILE_NOT_FOUND", fileName +"not Found"));
		}
		file.delete();
	}



	@Override
	public void init() {
		try {
			Files.createDirectories(rootLocation);
		}
		catch (IOException e) {
			throw new StorageException("Could not initialize storage", e);
		}
	}
}
