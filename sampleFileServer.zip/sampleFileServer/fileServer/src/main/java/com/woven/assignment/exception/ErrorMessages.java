package com.woven.assignment.exception;

public class ErrorMessages {
    public static final String WOVEN_FILE_SERVICE_SIZE_EXCEEDED = "max upload size is 50 MB";
}
