./mvnw install -DskipTests -pl fs-cli
cp fs-cli/target/fs-*.jar app.jar

